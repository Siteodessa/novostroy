blank theme based on wordpress official t-seventeen theme. styles and scripts removed.
has webpack and react