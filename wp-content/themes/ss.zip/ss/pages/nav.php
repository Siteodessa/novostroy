<nav id="main_navigation">
  <div>
    <ul class="menu">
      <li><span class="m_h"></span><a href="/">Главная</a></li>
      <li><span class="m_h"></span><a href="/stroyashhiesya-doma-v-odesse/">Строящиеся дома</a></li>
      <li><span class="m_h"></span><a href="/sdannye-doma-v-odesse/">Сданные дома</a></li>
      <li><span class="m_h"></span><a href="/ofisy-v-odesse/">Офисы</a></li>
      <li><span class="m_h"></span><a href="/tseny/">Цены</a></li>
      <li><span class="m_h"></span><a href="/goryashhie-predlozheniya/">Горящие предложения</a></li>
      <li><span class="m_h"></span><a href="/kontakty/">Контакты</a></li>
    </ul>
    <ul class="phones">
      <li><a>(048)736-80-94</a></li>
      <li><a>(096)323-29-13</a></li>
      <li><a>(066)787-06-23</a></li>
    </ul>
  </div>
</nav>
