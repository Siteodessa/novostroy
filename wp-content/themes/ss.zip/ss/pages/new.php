<?php get_header();?>
<?php/** * Template Name:  
* * @package WordPress 
* @subpackage Twenty_Fourteen 
* @since Twenty Fourteen 1.0 */?>
 

 
  <?php get_footer();?>